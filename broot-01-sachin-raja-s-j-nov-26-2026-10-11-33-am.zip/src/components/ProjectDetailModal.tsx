import { useEffect } from 'react';
import { X, ArrowUpRight, CheckCircle2, Clock, FileText, Users, Layers } from 'lucide-react';
import { ProjectItem } from '../data/portfolioData';
import { ResilientImage } from './ResilientImage';

interface ProjectDetailModalProps {
  project: ProjectItem | null;
  onClose: () => void;
  onSelectProject: (project: ProjectItem) => void;
  allProjects: ProjectItem[];
}

function StatusIndicator({ status, tone }: { status: string; tone: ProjectItem['statusTone'] }) {
  const colorClass =
    tone === 'emerald'
      ? 'text-emerald-400'
      : tone === 'blue'
      ? 'text-blue-400'
      : tone === 'amber'
      ? 'text-amber-300'
      : 'text-slate-300';

  const Icon = tone === 'emerald' ? CheckCircle2 : tone === 'blue' ? FileText : Clock;

  return (
    <span className={`inline-flex items-center gap-1.5 text-xs font-medium ${colorClass}`}>
      <Icon className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />
      <span>{status}</span>
    </span>
  );
}

export function ProjectDetailModal({
  project,
  onClose,
  onSelectProject,
  allProjects,
}: ProjectDetailModalProps) {
  useEffect(() => {
    if (!project) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [project, onClose]);

  if (!project) return null;

  const currentIdx = allProjects.findIndex((p) => p.id === project.id);
  const nextProject = allProjects[(currentIdx + 1) % allProjects.length];

  return (
    <div
      className="no-print fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 sm:p-6 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-labelledby="project-modal-title"
      onClick={onClose}
    >
      <div
        className="relative max-h-[90vh] w-full max-w-4xl overflow-y-auto rounded-2xl border border-slate-800 bg-[#0A1020] text-slate-100 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Sticky Modal Top Header */}
        <div className="sticky top-0 z-10 flex items-center justify-between gap-4 border-b border-slate-800/90 bg-[#0A1020]/95 px-6 py-4 backdrop-blur-md">
          <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-400">
            <span className="font-mono tabular-nums text-slate-300">{project.index}.</span>
            <span>{project.categoryLabel}</span>
            <span aria-hidden="true">·</span>
            <StatusIndicator status={project.status} tone={project.statusTone} />
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Close project details"
            className="inline-flex min-h-[40px] min-w-[40px] items-center justify-center rounded-lg border border-slate-800 bg-slate-900/80 text-slate-300 transition-colors hover:border-slate-700 hover:text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 cursor-pointer"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="p-6 sm:p-8 space-y-8">
          {/* Title & Lead */}
          <div className="space-y-3">
            <h2
              id="project-modal-title"
              className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-white [text-wrap:balance]"
            >
              {project.fullTitle}
            </h2>
            <p className="text-base leading-relaxed text-slate-300 max-w-3xl">{project.summary}</p>
          </div>

          {/* Visual Container */}
          {project.image && (
            <div className="aspect-[16/9] w-full overflow-hidden rounded-xl border border-slate-800 bg-[#060913]">
              <ResilientImage
                src={project.image}
                alt={project.imageAlt || project.name}
                fallbackTitle={project.name}
                className="h-full w-full object-cover"
              />
            </div>
          )}

          {/* Honesty / Stage Clarification Note */}
          {project.honestyNote && (
            <div className="rounded-xl border border-blue-500/25 bg-blue-950/20 px-5 py-4 text-sm leading-relaxed text-slate-200">
              <span className="font-semibold text-blue-300">Project Stage Note: </span>
              {project.honestyNote}
            </div>
          )}

          {/* Metadata Summary Strip (Zero-Pill Clean Typographic Columns) */}
          <div className="grid grid-cols-1 gap-6 border-y border-slate-800/80 py-6 sm:grid-cols-3">
            <div>
              <p className="text-xs font-medium text-slate-400">Technology Stack</p>
              <p className="mt-1.5 font-mono text-xs leading-relaxed text-slate-200">
                {project.stack.join(' / ')}
              </p>
            </div>
            <div>
              <p className="text-xs font-medium text-slate-400">Timeline &amp; Phase</p>
              <p className="mt-1.5 text-sm font-medium text-slate-200">{project.yearOrPhase}</p>
            </div>
            <div>
              <p className="text-xs font-medium text-slate-400">Current Status</p>
              <div className="mt-1.5">
                <StatusIndicator status={project.status} tone={project.statusTone} />
              </div>
            </div>
          </div>

          {/* Team & Guide if available */}
          {(project.team || project.guide) && (
            <div className="flex flex-col gap-3 rounded-xl border border-slate-800 bg-[#070B16] p-5 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex items-start gap-3">
                <Users className="mt-0.5 h-4 w-4 text-blue-400 shrink-0" aria-hidden="true" />
                <div className="text-sm text-slate-300 space-y-1">
                  {project.team && (
                    <p>
                      <span className="text-slate-400">Team: </span>
                      <span className="font-medium text-white">{project.team}</span>
                    </p>
                  )}
                  {project.guide && (
                    <p>
                      <span className="text-slate-400">Guide &amp; Co-author: </span>
                      <span className="font-medium text-white">{project.guide}</span>
                    </p>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Core Architectural Highlights */}
          <div className="space-y-4">
            <h3 className="font-display text-lg font-semibold text-white">
              Architecture &amp; Key Details
            </h3>
            <ul className="space-y-3">
              {project.highlights.map((item, idx) => (
                <li key={idx} className="flex items-start gap-3 text-sm leading-relaxed text-slate-300">
                  <span className="font-mono text-xs tabular-nums text-blue-400 pt-1">
                    0{idx + 1}
                  </span>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Optional Research Angle, Interfaces, Evaluation Plan & Outputs */}
          {(project.researchAngle || project.interfaces || project.evaluationPlan || project.outputs) && (
            <div className="grid grid-cols-1 gap-8 border-t border-slate-800/80 pt-6 md:grid-cols-2">
              {project.researchAngle && (
                <div className="space-y-2.5">
                  <h4 className="font-display text-base font-semibold text-white">Research Angle</h4>
                  <p className="text-sm leading-relaxed text-slate-300">{project.researchAngle}</p>
                </div>
              )}

              {project.interfaces && (
                <div className="space-y-2.5">
                  <h4 className="font-display text-base font-semibold text-white">
                    Planned System Interfaces
                  </h4>
                  <ul className="space-y-1.5 text-sm text-slate-300">
                    {project.interfaces.map((iface) => (
                      <li key={iface} className="flex items-center gap-2">
                        <Layers className="h-3.5 w-3.5 text-blue-400 shrink-0" aria-hidden="true" />
                        <span>{iface}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {project.evaluationPlan && (
                <div className="space-y-2.5">
                  <h4 className="font-display text-base font-semibold text-white">
                    Planned Evaluation Dimensions
                  </h4>
                  <ul className="space-y-1.5 text-sm text-slate-300">
                    {project.evaluationPlan.map((metric) => (
                      <li key={metric} className="text-slate-300">
                        · {metric}
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {project.outputs && (
                <div className="space-y-2.5">
                  <h4 className="font-display text-base font-semibold text-white">
                    Academic Outputs
                  </h4>
                  <ul className="space-y-1.5 text-sm text-slate-300">
                    {project.outputs.map((out) => (
                      <li key={out} className="text-slate-300">
                        · {out}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )}

          {/* Footer Navigation inside Modal */}
          <div className="flex flex-wrap items-center justify-between gap-4 border-t border-slate-800/80 pt-6">
            <button
              type="button"
              onClick={() => onSelectProject(nextProject)}
              className="inline-flex min-h-[40px] items-center gap-2 rounded-lg border border-slate-700 bg-slate-900 px-4 py-2 text-xs font-semibold text-slate-200 transition-colors hover:border-blue-500/60 hover:text-white whitespace-nowrap shrink-0 cursor-pointer"
            >
              <span>Next Project: {nextProject.name}</span>
              <ArrowUpRight className="h-3.5 w-3.5" aria-hidden="true" />
            </button>

            <button
              type="button"
              onClick={onClose}
              className="inline-flex min-h-[40px] items-center justify-center rounded-lg bg-blue-600 px-5 py-2 text-xs font-semibold text-white transition-colors hover:bg-blue-500 whitespace-nowrap shrink-0 cursor-pointer"
            >
              Back to Portfolio
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
