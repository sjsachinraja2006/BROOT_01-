import { useEffect, useState } from 'react';
import { X, Printer, Download, FileText } from 'lucide-react';
import {
  CERTIFICATIONS,
  EXPERIENCE_ITEMS,
  PORTFOLIO_PROFILE,
  SOFT_SKILLS,
} from '../data/portfolioData';

interface ResumeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function ResumeModal({ isOpen, onClose }: ResumeModalProps) {
  const [viewMode, setViewMode] = useState<'pdf' | 'summary'>('pdf');

  useEffect(() => {
    if (!isOpen) return;
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 sm:p-6 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-labelledby="resume-modal-title"
      onClick={onClose}
    >
      <div
        className="print-only-resume relative flex max-h-[92vh] w-full max-w-4xl flex-col overflow-hidden rounded-2xl border border-slate-800 bg-[#0A1020] text-slate-100 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header Bar */}
        <div className="no-print flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 bg-[#0A1020]/95 px-6 py-4 backdrop-blur-md">
          <div className="flex items-center gap-4">
            <h2 id="resume-modal-title" className="font-display text-base font-semibold text-white">
              Resume · {PORTFOLIO_PROFILE.name}
            </h2>

            {/* Segmented Mode Switcher */}
            <div
              role="tablist"
              aria-label="Resume view format"
              className="flex items-center gap-1 rounded-lg border border-slate-800 bg-[#060913] p-0.5"
            >
              <button
                type="button"
                role="tab"
                aria-selected={viewMode === 'pdf'}
                onClick={() => setViewMode('pdf')}
                className={`rounded-md px-2.5 py-1 text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  viewMode === 'pdf'
                    ? 'bg-blue-600 text-white'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                PDF Preview
              </button>
              <button
                type="button"
                role="tab"
                aria-selected={viewMode === 'summary'}
                onClick={() => setViewMode('summary')}
                className={`rounded-md px-2.5 py-1 text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  viewMode === 'summary'
                    ? 'bg-blue-600 text-white'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Structured View
              </button>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <a
              href={PORTFOLIO_PROFILE.resumePdfUrl}
              download="Sachin_Raja_SJ_Resume.pdf"
              className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg bg-blue-600 px-3.5 py-2 text-xs font-semibold text-white transition-colors hover:bg-blue-500 whitespace-nowrap shrink-0"
            >
              <Download className="h-3.5 w-3.5" aria-hidden="true" />
              <span>Download PDF</span>
            </a>
            {viewMode === 'summary' && (
              <button
                type="button"
                onClick={() => window.print()}
                className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-900 px-3.5 py-2 text-xs font-semibold text-slate-200 transition-colors hover:border-slate-600 hover:text-white whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Printer className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Print</span>
              </button>
            )}
            <button
              type="button"
              onClick={onClose}
              aria-label="Close resume preview"
              className="inline-flex min-h-[40px] min-w-[40px] items-center justify-center rounded-lg border border-slate-800 bg-slate-900 text-slate-300 hover:text-white cursor-pointer"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Body */}
        {viewMode === 'pdf' ? (
          <div className="flex-1 overflow-hidden bg-[#060913] p-4 sm:p-6">
            <div className="h-[68vh] w-full overflow-hidden rounded-xl border border-slate-800 bg-slate-950">
              <iframe
                src={PORTFOLIO_PROFILE.resumePdfUrl}
                title="Sachin Raja S J Resume PDF"
                className="h-full w-full"
              />
            </div>
            <div className="mt-3 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-400">
              <span className="inline-flex items-center gap-1.5">
                <FileText className="h-3.5 w-3.5 text-blue-400" aria-hidden="true" />
                <span>Prepared Resume PDF · {PORTFOLIO_PROFILE.name}</span>
              </span>
              <a
                href={PORTFOLIO_PROFILE.resumePdfUrl}
                target="_blank"
                rel="noreferrer"
                className="font-medium text-blue-400 hover:text-blue-300 underline underline-offset-4"
              >
                Open PDF in new tab
              </a>
            </div>
          </div>
        ) : (
          <div className="flex-1 overflow-y-auto space-y-6 p-6 sm:p-10 text-sm leading-relaxed">
            <div className="border-b border-slate-800 pb-5">
              <h1 className="font-display text-2xl font-bold tracking-tight text-white">
                SACHIN RAJA S J
              </h1>
              <p className="mt-1 text-xs text-slate-300">
                {PORTFOLIO_PROFILE.phone} · {PORTFOLIO_PROFILE.links.email} · GitHub · LinkedIn
              </p>
              <p className="mt-1 text-blue-400 font-medium">
                {PORTFOLIO_PROFILE.degree} ({PORTFOLIO_PROFILE.batch}) · CGPA: {PORTFOLIO_PROFILE.cgpa}
              </p>
            </div>

            <section className="space-y-2">
              <h3 className="font-display text-xs font-semibold tracking-wider text-slate-400">
                OBJECTIVE
              </h3>
              <p className="text-slate-300">
                Final year Computer Science Engineering student seeking a Software Developer or Java
                Full Stack Developer role where I can apply my programming, web development, and
                problem-solving skills while contributing to organizational growth and continuously
                enhancing my technical expertise.
              </p>
            </section>

            <section className="space-y-2">
              <h3 className="font-display text-xs font-semibold tracking-wider text-slate-400">
                EXPERIENCE
              </h3>
              {EXPERIENCE_ITEMS.map((exp) => (
                <div key={exp.id} className="space-y-1">
                  <p className="font-semibold text-white">
                    {exp.role} – {exp.organization}
                  </p>
                  <ul className="space-y-1 text-xs text-slate-300">
                    {exp.highlights.map((line) => (
                      <li key={line}>· {line}</li>
                    ))}
                  </ul>
                </div>
              ))}
            </section>

            <section className="space-y-2">
              <h3 className="font-display text-xs font-semibold tracking-wider text-slate-400">
                TECHNICAL SKILLS
              </h3>
              <div className="grid grid-cols-1 gap-2 sm:grid-cols-2 text-slate-300">
                <p>
                  <span className="font-semibold text-white">Programming:</span> Java, Python
                </p>
                <p>
                  <span className="font-semibold text-white">Databases:</span> MySQL, MongoDB,
                  PostgreSQL
                </p>
                <p>
                  <span className="font-semibold text-white">Concepts &amp; Web:</span> OOP, DBMS,
                  REST APIs, HTML, CSS, JS, Bootstrap, JDBC, JSP, React, FastAPI
                </p>
                <p>
                  <span className="font-semibold text-white">Tools:</span> VS Code, Eclipse, Figma,
                  XAMPP, Unity Hub, Blender, Canva, Autodesk
                </p>
              </div>
            </section>

            <section className="space-y-2">
              <h3 className="font-display text-xs font-semibold tracking-wider text-slate-400">
                ACHIEVEMENTS &amp; CERTIFICATIONS
              </h3>
              <ul className="space-y-1 text-xs text-slate-300">
                {CERTIFICATIONS.map((cert) => (
                  <li key={cert}>· {cert}</li>
                ))}
              </ul>
            </section>

            <section className="space-y-1.5 border-t border-slate-800 pt-4">
              <h3 className="font-display text-xs font-semibold tracking-wider text-slate-400">
                SOFT SKILLS
              </h3>
              <p className="text-xs text-slate-300">{SOFT_SKILLS.join(' · ')}</p>
            </section>
          </div>
        )}
      </div>
    </div>
  );
}
