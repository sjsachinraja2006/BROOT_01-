import { motion, useReducedMotion } from 'motion/react';
import { Award, BookOpen, Briefcase, FileText, GraduationCap } from 'lucide-react';
import {
  CERTIFICATIONS,
  EXPERIENCE_ITEMS,
  PORTFOLIO_PROFILE,
  RESEARCH_OUTPUTS,
} from '../data/portfolioData';

interface ResearchPageProps {
  onOpenResume: () => void;
}

export function ResearchPage({ onOpenResume }: ResearchPageProps) {
  const prefersReducedMotion = useReducedMotion();

  const headerMotion = prefersReducedMotion
    ? {}
    : {
        initial: { opacity: 0, y: 14 },
        animate: { opacity: 1, y: 0 },
        transition: { duration: 0.42, ease: [0.16, 1, 0.3, 1] as const },
      };

  return (
    <section className="mx-auto max-w-6xl px-6 py-14 lg:py-20 space-y-16">
      {/* Page Header */}
      <motion.div {...headerMotion} className="space-y-3 border-b border-slate-800/80 pb-10">
        <p className="font-mono text-xs font-medium text-blue-400">
          Research, Experience &amp; Credentials
        </p>
        <h1 className="font-display text-3xl font-bold tracking-tight text-white sm:text-4xl [text-wrap:balance]">
          IEEE manuscripts, internship training &amp; academic credentials.
        </h1>
        <p className="max-w-2xl text-sm leading-relaxed text-slate-400 sm:text-base">
          Academic engineering outputs, Java Full Stack internship experience, certifications, and
          B.E. CSE standing at K.S. Rangasamy College of Technology.
        </p>
      </motion.div>

      {/* Research & Literature Reviews */}
      <div className="divide-y divide-slate-800/80 border-b border-slate-800/80">
        {RESEARCH_OUTPUTS.map((item, idx) => (
          <motion.div
            key={item.id}
            initial={prefersReducedMotion ? false : { opacity: 0, y: 18 }}
            whileInView={prefersReducedMotion ? undefined : { opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.15 }}
            transition={{
              duration: 0.45,
              delay: prefersReducedMotion ? 0 : idx * 0.08,
              ease: [0.16, 1, 0.3, 1],
            }}
            className="grid grid-cols-1 gap-6 py-8 lg:grid-cols-12 lg:items-start"
          >
            <div className="lg:col-span-4 space-y-1.5">
              <div className="flex items-center gap-2 text-xs text-slate-400">
                <span className="font-mono tabular-nums text-blue-400">{item.index}.</span>
                <span>{item.venueOrType}</span>
              </div>
              <p className="text-xs font-medium text-slate-300">{item.status}</p>
              <p className="font-mono text-xs text-slate-400 pt-1">{item.formats.join(' · ')}</p>
            </div>

            <div className="lg:col-span-8 space-y-2.5">
              <h2 className="font-display text-xl font-semibold leading-snug text-white">
                {item.title}
              </h2>
              <p className="text-xs text-slate-400">{item.collaborators}</p>
              <p className="text-sm leading-relaxed text-slate-300">{item.description}</p>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Experience & Certifications */}
      <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
        <div className="rounded-2xl border border-slate-800 bg-[#0A1020] p-6 sm:p-7 space-y-4">
          <div className="flex items-center gap-2 text-xs font-medium text-blue-400">
            <Briefcase className="h-4 w-4" aria-hidden="true" />
            <span>Experience</span>
          </div>
          {EXPERIENCE_ITEMS.map((exp) => (
            <div key={exp.id} className="space-y-3">
              <div>
                <h2 className="font-display text-xl font-bold text-white">{exp.role}</h2>
                <p className="mt-0.5 text-xs font-medium text-slate-400">
                  {exp.organization} · {exp.type}
                </p>
              </div>
              <ul className="space-y-2 text-sm leading-relaxed text-slate-300">
                {exp.highlights.map((line) => (
                  <li key={line}>· {line}</li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="rounded-2xl border border-slate-800 bg-[#0A1020] p-6 sm:p-7 space-y-4">
          <div className="flex items-center gap-2 text-xs font-medium text-blue-400">
            <Award className="h-4 w-4" aria-hidden="true" />
            <span>Achievements &amp; Certifications</span>
          </div>
          <h2 className="font-display text-xl font-bold text-white">
            Verified Programs &amp; Credentials
          </h2>
          <ul className="space-y-2.5 text-sm leading-relaxed text-slate-300">
            {CERTIFICATIONS.map((cert) => (
              <li key={cert}>· {cert}</li>
            ))}
          </ul>
        </div>
      </div>

      {/* Education & Academic Credentials */}
      <div className="grid grid-cols-1 gap-8 rounded-2xl border border-slate-800 bg-[#0B1122] p-6 sm:p-8 lg:grid-cols-12 lg:items-center">
        <div className="lg:col-span-7 space-y-3">
          <div className="flex items-center gap-2 text-xs font-medium text-blue-400">
            <GraduationCap className="h-4 w-4" aria-hidden="true" />
            <span>Education &amp; Academic Standing</span>
          </div>
          <h2 className="font-display text-2xl font-bold tracking-tight text-white">
            {PORTFOLIO_PROFILE.degree}
          </h2>
          <p className="text-sm text-slate-300">{PORTFOLIO_PROFILE.institution}</p>
          <p className="text-xs text-slate-400 tabular-nums">
            Cohort {PORTFOLIO_PROFILE.batch} · CGPA: {PORTFOLIO_PROFILE.cgpa} · Focus: Java Full
            Stack Engineering &amp; Applied AI Systems
          </p>
        </div>

        <div className="lg:col-span-5 flex flex-col gap-3 border-t border-slate-800/80 pt-5 lg:border-t-0 lg:border-l lg:pl-8 lg:pt-0">
          <div className="flex items-start gap-3">
            <BookOpen className="mt-0.5 h-4 w-4 text-blue-400 shrink-0" aria-hidden="true" />
            <div className="text-xs leading-relaxed text-slate-300">
              <p className="font-semibold text-white">Placement &amp; Internship Ready</p>
              <p className="mt-1 text-slate-400">
                Open to Software Developer and Java Full Stack Developer roles.
              </p>
            </div>
          </div>
          <div>
            <button
              type="button"
              onClick={onOpenResume}
              className="inline-flex min-h-[40px] items-center gap-2 rounded-lg border border-slate-700 bg-slate-900 px-4 py-2 text-xs font-semibold text-white transition-colors hover:border-blue-500 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <FileText className="h-3.5 w-3.5 text-blue-400" aria-hidden="true" />
              <span>View &amp; Download Resume PDF</span>
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
