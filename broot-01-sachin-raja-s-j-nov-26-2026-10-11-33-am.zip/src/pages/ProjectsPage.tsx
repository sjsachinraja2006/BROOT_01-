import { useState } from 'react';
import { motion, useReducedMotion } from 'motion/react';
import { ArrowUpRight } from 'lucide-react';
import {
  PROJECTS,
  type ProjectFilterGroup,
  type ProjectItem,
} from '../data/portfolioData';
import { ResilientImage } from '../components/ResilientImage';

interface ProjectsPageProps {
  onSelectProject: (project: ProjectItem) => void;
}

const FILTER_TABS: { id: ProjectFilterGroup; label: string }[] = [
  { id: 'all', label: 'All Projects' },
  { id: 'deployed', label: 'Completed & Live' },
  { id: 'research', label: 'Research & Academic' },
  { id: 'systems', label: 'AI & Data Systems' },
  { id: 'design', label: 'UI/UX & Concepts' },
];

export function ProjectsPage({ onSelectProject }: ProjectsPageProps) {
  const prefersReducedMotion = useReducedMotion();
  const [activeFilter, setActiveFilter] = useState<ProjectFilterGroup>('all');

  const filteredProjects =
    activeFilter === 'all'
      ? PROJECTS
      : PROJECTS.filter((project) => project.filterGroup === activeFilter);

  const headerMotion = prefersReducedMotion
    ? {}
    : {
        initial: { opacity: 0, y: 14 },
        animate: { opacity: 1, y: 0 },
        transition: { duration: 0.42, ease: [0.16, 1, 0.3, 1] as const },
      };

  const projectGridVariants = {
    hidden: {},
    visible: {
      transition: {
        staggerChildren: prefersReducedMotion ? 0 : 0.09,
        delayChildren: prefersReducedMotion ? 0 : 0.04,
      },
    },
  };

  const projectCardVariants = prefersReducedMotion
    ? {
        hidden: { opacity: 1, y: 0, scale: 1 },
        visible: { opacity: 1, y: 0, scale: 1 },
      }
    : {
        hidden: { opacity: 0, y: 26, scale: 0.985 },
        visible: {
          opacity: 1,
          y: 0,
          scale: 1,
          transition: { duration: 0.5, ease: [0.16, 1, 0.3, 1] as const },
        },
      };

  return (
    <section className="mx-auto max-w-6xl px-6 py-14 lg:py-20">
      <motion.div
        {...headerMotion}
        className="flex flex-col gap-6 border-b border-slate-800/80 pb-10 md:flex-row md:items-end md:justify-between"
      >
        <div className="space-y-3">
          <p className="font-mono text-xs font-medium text-blue-400">Projects &amp; Case Studies</p>
          <h1 className="font-display text-3xl font-bold tracking-tight text-white sm:text-4xl [text-wrap:balance]">
            Projects, prototypes &amp; planned research.
          </h1>
          <p className="max-w-2xl text-sm leading-relaxed text-slate-400 sm:text-base">
            Each project is labeled honestly by stage—distinguishing completed deployments from
            Phase-I prototypes, technical builds, and research in the planning stage.
          </p>
        </div>

        {/* Functional Segmented Filter Controls */}
        <div
          role="tablist"
          aria-label="Filter projects by category"
          className="flex flex-wrap items-center gap-1 rounded-xl border border-slate-800 bg-[#0A1020] p-1"
        >
          {FILTER_TABS.map((tab) => {
            const isActive = activeFilter === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                role="tab"
                aria-selected={isActive}
                onClick={() => setActiveFilter(tab.id)}
                className={`min-h-[36px] rounded-lg px-3 py-1.5 text-xs font-medium transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer ${
                  isActive ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                {tab.label}
              </button>
            );
          })}
        </div>
      </motion.div>

      {/* Project Grid */}
      <motion.div
        key={activeFilter}
        variants={projectGridVariants}
        initial={prefersReducedMotion ? 'visible' : 'hidden'}
        whileInView="visible"
        viewport={{ once: true, amount: 0.05 }}
        className="mt-12 grid grid-cols-1 gap-6 md:grid-cols-2"
      >
        {filteredProjects.map((project, idx) => {
          const isWideHeroCard = activeFilter === 'all' && idx === 0;
          return (
            <motion.article
              key={project.id}
              variants={projectCardVariants}
              whileHover={prefersReducedMotion ? undefined : { y: -4 }}
              transition={{ y: { duration: 0.18, ease: [0.16, 1, 0.3, 1] } }}
              className={`group flex flex-col justify-between rounded-2xl border border-slate-800/90 bg-[#0B1122] transition-colors duration-200 hover:border-blue-500/50 ${
                isWideHeroCard ? 'md:col-span-2 lg:grid lg:grid-cols-12 lg:items-stretch' : ''
              }`}
            >
              {project.image && (
                <div
                  className={`overflow-hidden bg-[#060913] ${
                    isWideHeroCard
                      ? 'lg:col-span-6 rounded-t-2xl lg:rounded-l-2xl lg:rounded-tr-none aspect-[4/3] lg:aspect-auto'
                      : 'rounded-t-2xl aspect-[4/3]'
                  }`}
                >
                  <ResilientImage
                    src={project.image}
                    alt={project.imageAlt || project.name}
                    fallbackTitle={project.name}
                    className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-[1.02]"
                  />
                </div>
              )}

              <div
                className={`flex flex-col justify-between p-6 sm:p-7 ${
                  isWideHeroCard ? 'lg:col-span-6' : 'flex-1'
                }`}
              >
                <div className="space-y-3">
                  <div className="flex flex-wrap items-center gap-x-2.5 gap-y-1 text-xs text-slate-400">
                    <span className="font-mono tabular-nums text-slate-300">{project.index}.</span>
                    <span>{project.categoryLabel}</span>
                    <span aria-hidden="true">·</span>
                    <span
                      className={
                        project.statusTone === 'emerald'
                          ? 'font-medium text-emerald-400'
                          : project.statusTone === 'blue'
                          ? 'font-medium text-blue-400'
                          : project.statusTone === 'amber'
                          ? 'font-medium text-amber-300'
                          : 'font-medium text-slate-300'
                      }
                    >
                      {project.status}
                    </span>
                  </div>

                  <h2 className="font-display text-xl font-bold tracking-tight text-white">
                    {project.name}
                  </h2>

                  <p className="text-sm leading-relaxed text-slate-300">{project.summary}</p>
                </div>

                <div className="mt-6 space-y-4 border-t border-slate-800/80 pt-4">
                  <p className="font-mono text-xs text-slate-400">{project.stack.join(' / ')}</p>

                  <div className="flex items-center justify-between gap-4">
                    <span className="text-xs text-slate-400">{project.yearOrPhase}</span>

                    <button
                      type="button"
                      onClick={() => onSelectProject(project)}
                      className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-900/90 px-4 py-2 text-xs font-semibold text-white transition-colors duration-150 hover:border-blue-500 hover:bg-blue-600 whitespace-nowrap shrink-0 cursor-pointer"
                    >
                      <span>View Details</span>
                      <ArrowUpRight className="h-3.5 w-3.5" aria-hidden="true" />
                    </button>
                  </div>
                </div>
              </div>
            </motion.article>
          );
        })}
      </motion.div>
    </section>
  );
}
