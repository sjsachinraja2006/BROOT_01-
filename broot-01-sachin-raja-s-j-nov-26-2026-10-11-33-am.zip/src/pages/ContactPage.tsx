import { useEffect, useRef, useState, type FormEvent } from 'react';
import emailjs from '@emailjs/browser';
import { AnimatePresence, motion, useReducedMotion } from 'motion/react';
import {
  AlertCircle,
  ArrowUpRight,
  Check,
  CheckCircle2,
  Copy,
  FileText,
  Github,
  Linkedin,
  Loader2,
  Mail,
  Phone,
  Send,
  X,
} from 'lucide-react';
import { PORTFOLIO_PROFILE } from '../data/portfolioData';

interface ContactPageProps {
  onOpenResume: () => void;
}

interface ContactApiResult {
  ok: boolean;
  mode?: 'smtp' | 'resend' | 'mailto_fallback';
  receiverEmail?: string;
  message?: string;
  error?: string;
}

interface ToastState {
  id: number;
  type: 'success' | 'error';
  title: string;
  description: string;
}

const EMAILJS_SERVICE_ID = import.meta.env.VITE_EMAILJS_SERVICE_ID?.trim() || '';
const EMAILJS_TEMPLATE_ID = import.meta.env.VITE_EMAILJS_TEMPLATE_ID?.trim() || '';
const EMAILJS_PUBLIC_KEY = import.meta.env.VITE_EMAILJS_PUBLIC_KEY?.trim() || '';
const IS_EMAILJS_CONFIGURED = Boolean(
  EMAILJS_SERVICE_ID && EMAILJS_TEMPLATE_ID && EMAILJS_PUBLIC_KEY
);

export function ContactPage({ onOpenResume }: ContactPageProps) {
  const prefersReducedMotion = useReducedMotion();
  const [copiedEmail, setCopiedEmail] = useState(false);
  const [relayConfigured, setRelayConfigured] = useState<boolean | null>(null);

  const [senderName, setSenderName] = useState('');
  const [senderEmail, setSenderEmail] = useState('');
  const [subject, setSubject] = useState('Internship / Java Full Stack Opportunity');
  const [message, setMessage] = useState('');

  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState('');
  const [submitResult, setSubmitResult] = useState<{
    type: 'emailjs' | 'smtp' | 'resend' | 'mailto_fallback';
    message: string;
    receiverEmail?: string;
  } | null>(null);

  const [toast, setToast] = useState<ToastState | null>(null);
  const toastTimerRef = useRef<number | null>(null);

  const showToast = (type: 'success' | 'error', title: string, description: string) => {
    if (toastTimerRef.current) {
      window.clearTimeout(toastTimerRef.current);
    }
    const id = Date.now();
    setToast({ id, type, title, description });
    toastTimerRef.current = window.setTimeout(() => {
      setToast((current) => (current?.id === id ? null : current));
    }, 5500);
  };

  useEffect(() => {
    return () => {
      if (toastTimerRef.current) {
        window.clearTimeout(toastTimerRef.current);
      }
    };
  }, []);

  useEffect(() => {
    if (IS_EMAILJS_CONFIGURED) {
      setRelayConfigured(true);
      return;
    }

    let cancelled = false;
    fetch('/api/contact/status')
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (!cancelled && data && typeof data.emailConfigured === 'boolean') {
          setRelayConfigured(data.emailConfigured);
        }
      })
      .catch(() => {
        if (!cancelled) setRelayConfigured(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const handleCopyEmail = async () => {
    try {
      await navigator.clipboard.writeText(PORTFOLIO_PROFILE.links.email);
      setCopiedEmail(true);
      showToast('success', 'Email copied', `${PORTFOLIO_PROFILE.links.email} copied to clipboard.`);
      setTimeout(() => setCopiedEmail(false), 2500);
    } catch {
      setCopiedEmail(false);
    }
  };

  const openMailtoDraft = (receiver: string) => {
    const bodyText = `Hi Sachin,\n\n${message.trim()}\n\nBest regards,\n${senderName.trim()} (${senderEmail.trim()})`;
    const mailtoUrl = `mailto:${receiver}?subject=${encodeURIComponent(
      subject.trim()
    )}&body=${encodeURIComponent(bodyText)}`;
    window.location.href = mailtoUrl;
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setSubmitResult(null);

    const cleanName = senderName.trim();
    const cleanEmail = senderEmail.trim();
    const cleanSubject = subject.trim();
    const cleanMessage = message.trim();

    if (cleanName.length < 2) {
      const err = 'Please enter your name (at least 2 characters).';
      setFormError(err);
      showToast('error', 'Missing name', err);
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
      const err = 'Please provide a valid email address.';
      setFormError(err);
      showToast('error', 'Invalid email', err);
      return;
    }
    if (cleanSubject.length < 2) {
      const err = 'Please enter a subject.';
      setFormError(err);
      showToast('error', 'Missing subject', err);
      return;
    }
    if (cleanMessage.length < 10) {
      const err = 'Please enter a message of at least 10 characters.';
      setFormError(err);
      showToast('error', 'Message too short', err);
      return;
    }

    setFormError('');
    setSubmitting(true);

    try {
      // Primary path: EmailJS direct browser delivery when configured
      if (IS_EMAILJS_CONFIGURED) {
        await emailjs.send(
          EMAILJS_SERVICE_ID,
          EMAILJS_TEMPLATE_ID,
          {
            from_name: cleanName,
            from_email: cleanEmail,
            reply_to: cleanEmail,
            to_name: PORTFOLIO_PROFILE.name,
            to_email: PORTFOLIO_PROFILE.links.email,
            subject: cleanSubject,
            message: cleanMessage,
          },
          { publicKey: EMAILJS_PUBLIC_KEY }
        );

        const successMsg = 'Your message has been delivered directly via EmailJS.';
        setSubmitResult({ type: 'emailjs', message: successMsg });
        showToast('success', 'Message sent', successMsg);
        setSenderName('');
        setSenderEmail('');
        setMessage('');
        return;
      }

      // Secondary path: Express server relay (/api/contact) or honest mailto fallback
      const response = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: cleanName,
          email: cleanEmail,
          subject: cleanSubject,
          message: cleanMessage,
        }),
      });

      const data = (await response.json()) as ContactApiResult;

      if (!response.ok || !data.ok) {
        const errMsg = data.error || 'Unable to send your message right now. Please try again.';
        setFormError(errMsg);
        showToast('error', 'Delivery failed', errMsg);
        return;
      }

      if (data.mode === 'smtp' || data.mode === 'resend') {
        const msg = data.message || 'Your message has been delivered to Sachin’s inbox.';
        setSubmitResult({ type: data.mode, message: msg });
        showToast('success', 'Message sent', msg);
        setSenderName('');
        setSenderEmail('');
        setMessage('');
      } else {
        const fallbackMsg =
          'EmailJS keys are not configured yet (VITE_EMAILJS_SERVICE_ID, VITE_EMAILJS_TEMPLATE_ID, VITE_EMAILJS_PUBLIC_KEY). Opening your email client instead.';
        setSubmitResult({
          type: 'mailto_fallback',
          message: fallbackMsg,
          receiverEmail: data.receiverEmail || PORTFOLIO_PROFILE.links.email,
        });
        showToast('error', 'EmailJS not configured', 'Opened your email app as a fallback.');
        openMailtoDraft(data.receiverEmail || PORTFOLIO_PROFILE.links.email);
      }
    } catch (err) {
      const errorText =
        err instanceof Error && err.message
          ? `Could not send message: ${err.message}`
          : 'Failed to send message via EmailJS. Please try again or use the direct email link.';
      setFormError(errorText);
      showToast('error', 'Send failed', errorText);
    } finally {
      setSubmitting(false);
    }
  };

  const headerMotion = prefersReducedMotion
    ? {}
    : {
        initial: { opacity: 0, y: 14 },
        animate: { opacity: 1, y: 0 },
        transition: { duration: 0.42, ease: [0.16, 1, 0.3, 1] as const },
      };

  return (
    <section className="mx-auto max-w-6xl px-6 py-14 lg:py-20">
      <motion.div {...headerMotion} className="space-y-3 border-b border-slate-800/80 pb-10">
        <p className="font-mono text-xs font-medium text-blue-400">Contact &amp; Inquiries</p>
        <h1 className="font-display text-3xl font-bold tracking-tight text-white sm:text-4xl [text-wrap:balance]">
          Let’s connect for internships, roles &amp; builds.
        </h1>
        <p className="max-w-2xl text-sm leading-relaxed text-slate-400 sm:text-base">
          Send a message directly through the form below, copy my email address, inspect my CV, or
          visit my GitHub and LinkedIn profiles.
        </p>
      </motion.div>

      <div className="mt-12 grid grid-cols-1 gap-12 lg:grid-cols-12">
        {/* Left Info Column */}
        <div className="lg:col-span-5 space-y-6">
          <div className="space-y-4">
            <h2 className="font-display text-xl font-bold text-white">Direct Channels</h2>
            <p className="text-sm leading-relaxed text-slate-300">
              Open to Java Full Stack Developer internships, entry-level software engineering roles,
              and academic or applied AI collaborations.
            </p>
          </div>

          <div className="space-y-3 border-t border-slate-800/80 pt-6 text-sm">
            <div className="flex items-center justify-between gap-4 rounded-xl border border-slate-800 bg-[#0A1020] px-4 py-3">
              <div className="flex items-center gap-3 min-w-0">
                <Mail className="h-4 w-4 text-blue-400 shrink-0" aria-hidden="true" />
                <span className="truncate text-slate-200">{PORTFOLIO_PROFILE.links.email}</span>
              </div>
              <button
                type="button"
                onClick={handleCopyEmail}
                className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-900 px-3 py-1.5 text-xs font-medium text-slate-200 hover:text-white whitespace-nowrap shrink-0 cursor-pointer"
              >
                {copiedEmail ? (
                  <>
                    <Check className="h-3.5 w-3.5 text-emerald-400" aria-hidden="true" />
                    <span>Copied</span>
                  </>
                ) : (
                  <>
                    <Copy className="h-3.5 w-3.5" aria-hidden="true" />
                    <span>Copy</span>
                  </>
                )}
              </button>
            </div>

            <a
              href={`tel:${PORTFOLIO_PROFILE.phone.replace(/\s+/g, '')}`}
              className="flex min-h-[44px] items-center justify-between rounded-xl border border-slate-800 bg-[#0A1020] px-4 py-3 text-sm font-medium text-slate-200 transition-colors hover:border-blue-500/50 hover:text-white"
            >
              <span className="inline-flex items-center gap-3">
                <Phone className="h-4 w-4 text-blue-400 shrink-0" aria-hidden="true" />
                <span className="tabular-nums">{PORTFOLIO_PROFILE.phone}</span>
              </span>
              <span className="text-xs text-slate-400">Call</span>
            </a>

            <div className="grid grid-cols-2 gap-3">
              <a
                href={PORTFOLIO_PROFILE.links.github}
                target="_blank"
                rel="noreferrer"
                className="flex min-h-[44px] items-center justify-between rounded-xl border border-slate-800 bg-[#0A1020] px-4 py-3 text-sm font-medium text-slate-200 transition-colors hover:border-blue-500/50 hover:text-white"
              >
                <span className="inline-flex items-center gap-2">
                  <Github className="h-4 w-4 text-blue-400" aria-hidden="true" />
                  <span>GitHub</span>
                </span>
                <ArrowUpRight className="h-4 w-4 text-slate-400" aria-hidden="true" />
              </a>

              <a
                href={PORTFOLIO_PROFILE.links.linkedin}
                target="_blank"
                rel="noreferrer"
                className="flex min-h-[44px] items-center justify-between rounded-xl border border-slate-800 bg-[#0A1020] px-4 py-3 text-sm font-medium text-slate-200 transition-colors hover:border-blue-500/50 hover:text-white"
              >
                <span className="inline-flex items-center gap-2">
                  <Linkedin className="h-4 w-4 text-blue-400" aria-hidden="true" />
                  <span>LinkedIn</span>
                </span>
                <ArrowUpRight className="h-4 w-4 text-slate-400" aria-hidden="true" />
              </a>
            </div>

            <button
              type="button"
              onClick={onOpenResume}
              className="flex min-h-[44px] w-full items-center justify-between rounded-xl border border-slate-800 bg-[#0A1020] px-4 py-3 text-sm font-medium text-slate-200 transition-colors hover:border-blue-500/50 hover:text-white cursor-pointer"
            >
              <span className="inline-flex items-center gap-2">
                <FileText className="h-4 w-4 text-blue-400" aria-hidden="true" />
                <span>Inspect &amp; Download Resume</span>
              </span>
              <ArrowUpRight className="h-4 w-4 text-slate-400" aria-hidden="true" />
            </button>
          </div>
        </div>

        {/* Right Column: EmailJS Contact Form */}
        <div className="lg:col-span-7">
          <form
            onSubmit={handleSubmit}
            noValidate
            className="rounded-2xl border border-slate-800 bg-[#0A1020] p-6 sm:p-8 space-y-5"
          >
            <div className="space-y-1">
              <h2 className="font-display text-lg font-semibold text-white">
                Send a Direct Message
              </h2>
              <p className="text-xs text-slate-400">
                {IS_EMAILJS_CONFIGURED
                  ? 'Powered by EmailJS — messages are delivered directly to Sachin’s inbox.'
                  : relayConfigured
                  ? 'Delivered directly to Sachin’s inbox via server mail relay.'
                  : 'Configure EmailJS keys (VITE_EMAILJS_*) to send directly from this form, or submit to open your email app.'}
              </p>
            </div>

            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div className="space-y-1.5">
                <label htmlFor="contact-name" className="block text-xs font-medium text-slate-300">
                  Your Name
                </label>
                <input
                  id="contact-name"
                  name="from_name"
                  type="text"
                  value={senderName}
                  onChange={(e) => setSenderName(e.target.value)}
                  placeholder="Recruiter or collaborator name"
                  className="w-full min-h-[42px] rounded-lg border border-slate-800 bg-[#060913] px-3.5 py-2 text-sm text-white placeholder:text-slate-500 focus:border-blue-500 focus:outline-none"
                />
              </div>

              <div className="space-y-1.5">
                <label htmlFor="contact-email" className="block text-xs font-medium text-slate-300">
                  Email Address
                </label>
                <input
                  id="contact-email"
                  name="from_email"
                  type="email"
                  value={senderEmail}
                  onChange={(e) => setSenderEmail(e.target.value)}
                  placeholder="you@company.com"
                  className="w-full min-h-[42px] rounded-lg border border-slate-800 bg-[#060913] px-3.5 py-2 text-sm text-white placeholder:text-slate-500 focus:border-blue-500 focus:outline-none"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <label htmlFor="contact-subject" className="block text-xs font-medium text-slate-300">
                Subject
              </label>
              <input
                id="contact-subject"
                name="subject"
                type="text"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                className="w-full min-h-[42px] rounded-lg border border-slate-800 bg-[#060913] px-3.5 py-2 text-sm text-white placeholder:text-slate-500 focus:border-blue-500 focus:outline-none"
              />
            </div>

            <div className="space-y-1.5">
              <label htmlFor="contact-message" className="block text-xs font-medium text-slate-300">
                Message
              </label>
              <textarea
                id="contact-message"
                name="message"
                rows={5}
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Share details about a Java Full Stack role, internship, or project collaboration..."
                className="w-full rounded-lg border border-slate-800 bg-[#060913] px-3.5 py-2.5 text-sm text-white placeholder:text-slate-500 focus:border-blue-500 focus:outline-none"
              />
            </div>

            {formError && (
              <p role="alert" className="text-xs font-medium text-amber-300">
                {formError}
              </p>
            )}

            {submitResult && !formError && (
              <div
                role="status"
                className={`rounded-xl border px-4 py-3 text-xs leading-relaxed ${
                  submitResult.type !== 'mailto_fallback'
                    ? 'border-emerald-500/30 bg-emerald-950/25 text-emerald-300'
                    : 'border-blue-500/30 bg-blue-950/25 text-slate-200'
                }`}
              >
                <p>{submitResult.message}</p>
                {submitResult.type === 'mailto_fallback' && (
                  <button
                    type="button"
                    onClick={() =>
                      openMailtoDraft(submitResult.receiverEmail || PORTFOLIO_PROFILE.links.email)
                    }
                    className="mt-2 inline-flex items-center gap-1.5 font-semibold text-blue-300 underline underline-offset-4 hover:text-white cursor-pointer"
                  >
                    <span>Open Email Client Again</span>
                    <ArrowUpRight className="h-3.5 w-3.5" aria-hidden="true" />
                  </button>
                )}
              </div>
            )}

            <div className="flex items-center justify-end">
              <button
                type="submit"
                disabled={submitting}
                className="inline-flex min-h-[44px] items-center gap-2 rounded-lg bg-blue-600 px-6 py-2.5 text-sm font-semibold text-white transition-colors duration-150 hover:bg-blue-500 disabled:opacity-60 whitespace-nowrap shrink-0 cursor-pointer"
              >
                {submitting ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
                    <span>Sending...</span>
                  </>
                ) : (
                  <>
                    <Send className="h-4 w-4" aria-hidden="true" />
                    <span>Send Message</span>
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      </div>

      {/* Feedback Toast Notification */}
      <AnimatePresence>
        {toast && (
          <motion.div
            key={toast.id}
            role={toast.type === 'error' ? 'alert' : 'status'}
            aria-live="polite"
            initial={prefersReducedMotion ? { opacity: 1 } : { opacity: 0, y: 16, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={prefersReducedMotion ? { opacity: 0 } : { opacity: 0, y: 12, scale: 0.98 }}
            transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
            className={`fixed right-5 bottom-5 z-50 flex w-full max-w-sm items-start gap-3 rounded-xl border p-4 shadow-2xl backdrop-blur-md ${
              toast.type === 'success'
                ? 'border-emerald-500/40 bg-[#0A1816]/95 text-emerald-100'
                : 'border-rose-500/40 bg-[#1A0C12]/95 text-rose-100'
            }`}
          >
            {toast.type === 'success' ? (
              <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-emerald-400" aria-hidden="true" />
            ) : (
              <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-rose-400" aria-hidden="true" />
            )}

            <div className="min-w-0 flex-1 space-y-0.5">
              <p className="text-xs font-semibold">{toast.title}</p>
              <p className="text-xs leading-relaxed opacity-85">{toast.description}</p>
            </div>

            <button
              type="button"
              onClick={() => setToast(null)}
              aria-label="Dismiss notification"
              className="inline-flex h-7 w-7 shrink-0 items-center justify-center rounded-md text-slate-300 hover:bg-white/10 hover:text-white cursor-pointer"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
