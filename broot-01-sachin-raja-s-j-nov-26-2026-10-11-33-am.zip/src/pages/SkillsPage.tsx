import { motion, useReducedMotion } from 'motion/react';
import { ArrowRight, FileText } from 'lucide-react';
import { SKILL_GROUPS, SOFT_SKILLS } from '../data/portfolioData';
import type { AppRoute } from './HomePage';

interface SkillsPageProps {
  onNavigate: (route: AppRoute) => void;
  onOpenResume: () => void;
}

export function SkillsPage({ onNavigate, onOpenResume }: SkillsPageProps) {
  const prefersReducedMotion = useReducedMotion();

  const headerMotion = prefersReducedMotion
    ? {}
    : {
        initial: { opacity: 0, y: 14 },
        animate: { opacity: 1, y: 0 },
        transition: { duration: 0.42, ease: [0.16, 1, 0.3, 1] as const },
      };

  const skillGridVariants = {
    hidden: {},
    visible: {
      transition: {
        staggerChildren: prefersReducedMotion ? 0 : 0.12,
        delayChildren: prefersReducedMotion ? 0 : 0.05,
      },
    },
  };

  const skillCardVariants = prefersReducedMotion
    ? {
        hidden: { opacity: 1, y: 0, scale: 1 },
        visible: { opacity: 1, y: 0, scale: 1 },
      }
    : {
        hidden: { opacity: 0, y: 24, scale: 0.985 },
        visible: {
          opacity: 1,
          y: 0,
          scale: 1,
          transition: { duration: 0.5, ease: [0.16, 1, 0.3, 1] as const },
        },
      };

  const skillListVariants = {
    hidden: {},
    visible: {
      transition: {
        staggerChildren: prefersReducedMotion ? 0 : 0.04,
        delayChildren: prefersReducedMotion ? 0 : 0.1,
      },
    },
  };

  const skillRowVariants = prefersReducedMotion
    ? {
        hidden: { opacity: 1, x: 0 },
        visible: { opacity: 1, x: 0 },
      }
    : {
        hidden: { opacity: 0, x: -8 },
        visible: {
          opacity: 1,
          x: 0,
          transition: { duration: 0.35, ease: [0.16, 1, 0.3, 1] as const },
        },
      };

  return (
    <section className="mx-auto max-w-6xl px-6 py-14 lg:py-20">
      <motion.div
        {...headerMotion}
        className="flex flex-col gap-6 border-b border-slate-800/80 pb-10 md:flex-row md:items-end md:justify-between"
      >
        <div className="space-y-3">
          <p className="font-mono text-xs font-medium text-blue-400">Technical Skills</p>
          <h1 className="font-display text-3xl font-bold tracking-tight text-white sm:text-4xl [text-wrap:balance]">
            Core Java Full Stack foundation &amp; applied AI tooling.
          </h1>
          <p className="max-w-2xl text-sm leading-relaxed text-slate-400 sm:text-base">
            Organized around technologies used directly across coursework, Eduskills internship
            projects, database engineering, and research prototypes.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={onOpenResume}
            className="inline-flex min-h-[40px] items-center gap-2 rounded-lg border border-slate-700 bg-[#0A1020] px-4 py-2 text-xs font-semibold text-slate-200 transition-colors hover:border-blue-500 hover:text-white whitespace-nowrap shrink-0 cursor-pointer"
          >
            <FileText className="h-3.5 w-3.5 text-blue-400" aria-hidden="true" />
            <span>View Resume</span>
          </button>
          <a
            href="/projects"
            onClick={(e) => {
              e.preventDefault();
              onNavigate('/projects');
            }}
            className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg bg-blue-600 px-4 py-2 text-xs font-semibold text-white transition-colors hover:bg-blue-500 whitespace-nowrap shrink-0"
          >
            <span>See Applied Projects</span>
            <ArrowRight className="h-3.5 w-3.5" aria-hidden="true" />
          </a>
        </div>
      </motion.div>

      <motion.div
        variants={skillGridVariants}
        initial={prefersReducedMotion ? 'visible' : 'hidden'}
        whileInView="visible"
        viewport={{ once: true, amount: 0.1 }}
        className="mt-12 grid grid-cols-1 gap-6 md:grid-cols-2"
      >
        {SKILL_GROUPS.map((group) => (
          <motion.div
            key={group.id}
            variants={skillCardVariants}
            whileHover={prefersReducedMotion ? undefined : { y: -3 }}
            transition={{ y: { duration: 0.18, ease: [0.16, 1, 0.3, 1] } }}
            className="rounded-2xl border border-slate-800/90 bg-[#0A1020] p-6 sm:p-7 space-y-5 transition-colors duration-200 hover:border-blue-500/40"
          >
            <div className="space-y-2 border-b border-slate-800/80 pb-4">
              <div className="flex items-center justify-between gap-4 text-xs">
                <span className="font-mono tabular-nums text-blue-400">{group.index}.</span>
                <span className="font-medium text-slate-400">{group.emphasis}</span>
              </div>
              <h2 className="font-display text-xl font-bold tracking-tight text-white">
                {group.title}
              </h2>
              <p className="text-sm leading-relaxed text-slate-400">{group.description}</p>
            </div>

            <motion.ul variants={skillListVariants} className="space-y-3">
              {group.skills.map((skill) => (
                <motion.li
                  key={skill.name}
                  variants={skillRowVariants}
                  className="flex flex-col gap-0.5 sm:flex-row sm:items-baseline sm:justify-between sm:gap-4"
                >
                  <span
                    className={`text-sm font-semibold ${
                      skill.primary ? 'text-blue-300' : 'text-slate-100'
                    }`}
                  >
                    {skill.name}
                  </span>
                  <span className="text-xs text-slate-400 sm:text-right">{skill.context}</span>
                </motion.li>
              ))}
            </motion.ul>
          </motion.div>
        ))}
      </motion.div>

      <div className="mt-10 rounded-2xl border border-slate-800/90 bg-[#0A1020] px-6 py-5 sm:flex sm:items-center sm:justify-between sm:gap-6">
        <p className="font-mono text-xs font-medium text-blue-400 shrink-0">Soft Skills</p>
        <p className="mt-2 text-sm text-slate-300 sm:mt-0">{SOFT_SKILLS.join(' · ')}</p>
      </div>
    </section>
  );
}
