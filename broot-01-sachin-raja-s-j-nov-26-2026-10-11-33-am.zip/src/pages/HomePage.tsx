import { motion, useReducedMotion } from 'motion/react';
import { ArrowRight, FileText, Github, Linkedin } from 'lucide-react';
import { KEY_HIGHLIGHTS, PORTFOLIO_PROFILE } from '../data/portfolioData';
import { ResilientImage } from '../components/ResilientImage';

export type AppRoute = '/' | '/projects' | '/skills' | '/research' | '/contact';

interface HomePageProps {
  onNavigate: (route: AppRoute) => void;
  onOpenResume: () => void;
}

const DIRECTORY_LINKS: { route: AppRoute; index: string; title: string; summary: string }[] = [
  {
    route: '/projects',
    index: '01',
    title: 'Projects & Case Studies',
    summary: 'Live UI work, Phase-I prototypes, applied AI builds, and EvalPoint research.',
  },
  {
    route: '/skills',
    index: '02',
    title: 'Technical Skills',
    summary: 'Java Full Stack core (Spring Boot, JDBC, MySQL) alongside RAG, GIS, and React.',
  },
  {
    route: '/research',
    index: '03',
    title: 'Research & Education',
    summary: 'IEEE manuscript, 50 synthesized papers across two reviews, and B.E. CSE credentials.',
  },
  {
    route: '/contact',
    index: '04',
    title: 'Contact & Inquiries',
    summary: 'Send a direct email via the integrated contact form or connect on GitHub & LinkedIn.',
  },
];

export function HomePage({ onNavigate, onOpenResume }: HomePageProps) {
  const prefersReducedMotion = useReducedMotion();

  const heroMotion = prefersReducedMotion
    ? {}
    : {
        initial: { opacity: 0, y: 12 },
        animate: { opacity: 1, y: 0 },
        transition: { duration: 0.45, ease: [0.16, 1, 0.3, 1] as const },
      };

  return (
    <>
      {/* HERO SECTION — Split-Screen Editorial Architecture */}
      <section className="mx-auto max-w-6xl px-6 pt-12 pb-14 lg:pt-16 lg:pb-20">
        <div className="grid grid-cols-1 gap-10 lg:grid-cols-12 lg:items-stretch">
          {/* Left Column: Typographic Hierarchy */}
          <motion.div
            {...heroMotion}
            className="flex flex-col justify-between lg:col-span-7 lg:pr-4"
          >
            <div className="space-y-6">
              <p className="text-sm font-medium tracking-wide text-blue-400">
                {PORTFOLIO_PROFILE.roleHeadline}
              </p>

              <h1 className="font-display text-4xl font-bold tracking-tight text-white sm:text-5xl lg:text-[3.5rem] lg:leading-[1.08] [text-wrap:balance]">
                {PORTFOLIO_PROFILE.name}
              </h1>

              <p className="max-w-xl text-base leading-relaxed text-slate-300 sm:text-lg">
                {PORTFOLIO_PROFILE.heroSummary}
              </p>
            </div>

            <div className="mt-8 space-y-6">
              {/* Primary & Secondary CTAs */}
              <div className="flex flex-wrap items-center gap-4">
                <a
                  href="/projects"
                  onClick={(e) => {
                    e.preventDefault();
                    onNavigate('/projects');
                  }}
                  className="inline-flex min-h-[44px] items-center gap-2 rounded-lg bg-blue-600 px-6 py-2.5 text-sm font-semibold text-white transition-colors duration-150 hover:bg-blue-500 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400"
                >
                  <span>Explore My Work</span>
                  <ArrowRight className="h-4 w-4" aria-hidden="true" />
                </a>

                <a
                  href="/contact"
                  onClick={(e) => {
                    e.preventDefault();
                    onNavigate('/contact');
                  }}
                  className="inline-flex min-h-[44px] items-center gap-2 rounded-lg border border-slate-700 bg-[#0B1122] px-6 py-2.5 text-sm font-semibold text-slate-200 transition-colors duration-150 hover:border-slate-500 hover:text-white whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500"
                >
                  <span>Contact Me</span>
                </a>
              </div>

              {/* Unboxed External Profile Row */}
              <div className="flex flex-wrap items-center gap-x-5 gap-y-2 border-t border-slate-800/80 pt-5 text-xs font-medium text-slate-400">
                <a
                  href={PORTFOLIO_PROFILE.links.github}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1.5 text-slate-300 transition-colors hover:text-white"
                >
                  <Github className="h-3.5 w-3.5 text-blue-400" aria-hidden="true" />
                  <span>GitHub</span>
                </a>
                <span aria-hidden="true">·</span>
                <a
                  href={PORTFOLIO_PROFILE.links.linkedin}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1.5 text-slate-300 transition-colors hover:text-white"
                >
                  <Linkedin className="h-3.5 w-3.5 text-blue-400" aria-hidden="true" />
                  <span>LinkedIn</span>
                </a>
                <span aria-hidden="true">·</span>
                <button
                  type="button"
                  onClick={onOpenResume}
                  className="inline-flex items-center gap-1.5 text-slate-300 transition-colors hover:text-white cursor-pointer"
                >
                  <FileText className="h-3.5 w-3.5 text-blue-400" aria-hidden="true" />
                  <span>Download Resume</span>
                </button>
                <span aria-hidden="true">·</span>
                <span className="text-slate-400">{PORTFOLIO_PROFILE.location}</span>
              </div>
            </div>
          </motion.div>

          {/* Right Column: Matching-Height Key Visual */}
          <div className="lg:col-span-5">
            <div className="relative h-full min-h-[280px] overflow-hidden rounded-2xl border border-slate-800 bg-[#0A1020]">
              <ResilientImage
                src={PORTFOLIO_PROFILE.heroImage}
                alt="Architectural wireframe and smoked glass sculpture representing software systems engineering"
                fallbackTitle="BROOT_01 · Systems & Design"
                className="h-full w-full object-cover"
              />
              <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#060913]/90 via-[#060913]/20 to-transparent" />
              <div className="absolute inset-x-0 bottom-0 p-5">
                <p className="font-mono text-xs text-blue-300">
                  BROOT_01 · {PORTFOLIO_PROFILE.batch}
                </p>
                <p className="mt-1 text-sm font-medium text-slate-200">
                  {PORTFOLIO_PROFILE.institution}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* 4-Column Highlights Strip Below Hero Split */}
        <div className="mt-12 grid grid-cols-1 gap-6 border-y border-slate-800/80 py-6 sm:grid-cols-2 lg:grid-cols-4">
          {KEY_HIGHLIGHTS.map((item) => (
            <div key={item.value} className="space-y-1">
              <p className="font-display text-xl font-bold tracking-tight text-white tabular-nums">
                {item.value}
              </p>
              <p className="text-xs leading-relaxed text-slate-400">{item.label}</p>
            </div>
          ))}
        </div>
      </section>

      {/* SUBTLE EDITORIAL MARQUEE DIVIDER */}
      <div
        aria-hidden="true"
        className="overflow-hidden border-y border-slate-800/60 bg-[#080D1A] py-3 select-none"
      >
        <div className="animate-marquee flex w-max items-center gap-8 whitespace-nowrap font-mono text-xs tracking-wide text-slate-400">
          <span>java full stack engineering</span>
          <span>·</span>
          <span>pixelnest collaboration ui</span>
          <span>·</span>
          <span>evalpoint rubric research</span>
          <span>·</span>
          <span>sql window functions</span>
          <span>·</span>
          <span>python rag &amp; faiss</span>
          <span>·</span>
          <span>gis flood intelligence</span>
          <span>·</span>
          <span>curriculum time estimation</span>
          <span>·</span>
          <span>java full stack engineering</span>
          <span>·</span>
          <span>pixelnest collaboration ui</span>
          <span>·</span>
          <span>evalpoint rubric research</span>
          <span>·</span>
          <span>sql window functions</span>
          <span>·</span>
          <span>python rag &amp; faiss</span>
          <span>·</span>
          <span>gis flood intelligence</span>
          <span>·</span>
          <span>curriculum time estimation</span>
        </div>
      </div>

      {/* ABOUT & ENGINEERING DIRECTION */}
      <section className="mx-auto max-w-6xl px-6 py-20">
        <div className="grid grid-cols-1 gap-12 lg:grid-cols-12">
          <div className="lg:col-span-4 space-y-3">
            <p className="font-mono text-xs font-medium text-blue-400">01. About Me</p>
            <h2 className="font-display text-3xl font-bold tracking-tight text-white [text-wrap:balance]">
              Engineering systems with clarity and intent.
            </h2>
          </div>

          <div className="lg:col-span-8 space-y-6 text-base leading-relaxed text-slate-300">
            <p>
              I am <span className="font-semibold text-white">Sachin Raja S J</span>, a final-year
              B.E. Computer Science and Engineering student (2023–2027, CGPA: 7.45) at{' '}
              <span className="text-slate-100">
                K.S. Rangasamy College of Technology (Autonomous), Tiruchengode
              </span>
              . Trained through the{' '}
              <span className="font-semibold text-blue-300">
                Eduskills Java Full Stack Development Internship
              </span>
              , I build structured object-oriented Java services, JDBC/JSP layers, REST APIs, and
              MySQL/MongoDB/PostgreSQL databases paired with responsive frontends.
            </p>
            <p>
              Certified in NASSCOM Digital Engineering and the Wadhwani Foundation Ignite India
              Program, I also build applied AI systems across education, agriculture, and disaster
              preparedness—always distinguishing live work from prototypes and planned research.
            </p>

            <div className="grid grid-cols-1 gap-6 border-t border-slate-800/80 pt-6 sm:grid-cols-3">
              <div>
                <p className="text-xs font-medium text-slate-400">Primary Track</p>
                <p className="mt-1 text-sm font-semibold text-white">Java Full Stack</p>
                <p className="mt-0.5 text-xs text-slate-400">Java · JDBC · JSP · MySQL · MongoDB</p>
              </div>
              <div>
                <p className="text-xs font-medium text-slate-400">Applied Domains</p>
                <p className="mt-1 text-sm font-semibold text-white">EdTech, AgriTech &amp; GIS</p>
                <p className="mt-0.5 text-xs text-slate-400">FastAPI · RAG · FAISS · PostgreSQL</p>
              </div>
              <div>
                <p className="text-xs font-medium text-slate-400">Design &amp; Tooling</p>
                <p className="mt-1 text-sm font-semibold text-white">Interface &amp; 3D Craft</p>
                <p className="mt-0.5 text-xs text-slate-400">React · Bootstrap · Figma · Blender</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* PORTFOLIO DIRECTORY — Navigate to Separate Pages */}
      <section className="border-t border-slate-800/80 bg-[#070B16]">
        <div className="mx-auto max-w-6xl px-6 py-16">
          <div className="mb-8 space-y-2">
            <p className="font-mono text-xs font-medium text-blue-400">02. Explore Portfolio</p>
            <h2 className="font-display text-2xl font-bold tracking-tight text-white">
              Dedicated sections by discipline.
            </h2>
          </div>

          <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {DIRECTORY_LINKS.map((item) => (
              <a
                key={item.route}
                href={item.route}
                onClick={(e) => {
                  e.preventDefault();
                  onNavigate(item.route);
                }}
                className="group flex flex-col justify-between rounded-2xl border border-slate-800/90 bg-[#0B1122] p-6 transition-colors duration-150 hover:border-blue-500/50"
              >
                <div className="space-y-3">
                  <span className="font-mono text-xs tabular-nums text-blue-400">
                    {item.index}.
                  </span>
                  <h3 className="font-display text-lg font-semibold text-white group-hover:text-blue-300 transition-colors">
                    {item.title}
                  </h3>
                  <p className="text-xs leading-relaxed text-slate-400">{item.summary}</p>
                </div>
                <div className="mt-6 flex items-center gap-1.5 text-xs font-semibold text-slate-200 group-hover:text-white">
                  <span>Open page</span>
                  <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-0.5" aria-hidden="true" />
                </div>
              </a>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
