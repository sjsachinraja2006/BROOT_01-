/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useCallback, useEffect, useState } from 'react';
import { PORTFOLIO_PROFILE, PROJECTS, type ProjectItem } from './data/portfolioData';
import { Navbar } from './components/Navbar';
import { ProjectDetailModal } from './components/ProjectDetailModal';
import { ResumeModal } from './components/ResumeModal';
import { HomePage, type AppRoute } from './pages/HomePage';
import { ProjectsPage } from './pages/ProjectsPage';
import { SkillsPage } from './pages/SkillsPage';
import { ResearchPage } from './pages/ResearchPage';
import { ContactPage } from './pages/ContactPage';

const VALID_ROUTES: AppRoute[] = ['/', '/projects', '/skills', '/research', '/contact'];

function resolveRoute(pathname: string): AppRoute {
  const normalized = pathname.replace(/\/+$/, '') || '/';
  return VALID_ROUTES.includes(normalized as AppRoute) ? (normalized as AppRoute) : '/';
}

export default function App() {
  const [currentRoute, setCurrentRoute] = useState<AppRoute>(() =>
    resolveRoute(window.location.pathname)
  );
  const [selectedProject, setSelectedProject] = useState<ProjectItem | null>(null);
  const [resumeOpen, setResumeOpen] = useState(false);

  useEffect(() => {
    const handlePopState = () => {
      setCurrentRoute(resolveRoute(window.location.pathname));
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const navigate = useCallback(
    (route: AppRoute) => {
      if (route !== currentRoute) {
        window.history.pushState({}, '', route);
        setCurrentRoute(route);
      }
      window.scrollTo({ top: 0, behavior: 'instant' });
    },
    [currentRoute]
  );

  return (
    <div id="top" className="flex min-h-screen flex-col bg-[#060913] text-slate-100">
      {/* Subtle top atmospheric glow */}
      <div
        aria-hidden="true"
        className="pointer-events-none fixed inset-x-0 top-0 -z-10 h-[540px] bg-[radial-gradient(ellipse_65%_50%_at_50%_-10%,rgba(37,99,235,0.16),rgba(79,70,229,0.06)_50%,transparent)]"
      />

      <Navbar
        currentRoute={currentRoute}
        onNavigate={navigate}
        onOpenResume={() => setResumeOpen(true)}
      />

      <main className="no-print flex-1">
        {currentRoute === '/' && (
          <HomePage onNavigate={navigate} onOpenResume={() => setResumeOpen(true)} />
        )}
        {currentRoute === '/projects' && (
          <ProjectsPage onSelectProject={(project) => setSelectedProject(project)} />
        )}
        {currentRoute === '/skills' && (
          <SkillsPage onNavigate={navigate} onOpenResume={() => setResumeOpen(true)} />
        )}
        {currentRoute === '/research' && (
          <ResearchPage onOpenResume={() => setResumeOpen(true)} />
        )}
        {currentRoute === '/contact' && (
          <ContactPage onOpenResume={() => setResumeOpen(true)} />
        )}
      </main>

      {/* CLEAN FOOTER */}
      <footer className="no-print border-t border-slate-800/80 bg-[#060913]">
        <div className="mx-auto flex max-w-6xl flex-col gap-4 px-6 py-8 sm:flex-row sm:items-center sm:justify-between">
          <div className="text-xs text-slate-400">
            <span className="font-display font-semibold text-slate-200">
              {PORTFOLIO_PROFILE.brand}
            </span>{' '}
            · {PORTFOLIO_PROFILE.name} · B.E. CSE {PORTFOLIO_PROFILE.batch}
          </div>

          <div className="flex flex-wrap items-center gap-6 text-xs text-slate-400">
            <a
              href="/"
              onClick={(e) => {
                e.preventDefault();
                navigate('/');
              }}
              className="hover:text-white transition-colors"
            >
              Home
            </a>
            <a
              href="/projects"
              onClick={(e) => {
                e.preventDefault();
                navigate('/projects');
              }}
              className="hover:text-white transition-colors"
            >
              Projects
            </a>
            <a
              href="/skills"
              onClick={(e) => {
                e.preventDefault();
                navigate('/skills');
              }}
              className="hover:text-white transition-colors"
            >
              Skills
            </a>
            <a
              href="/research"
              onClick={(e) => {
                e.preventDefault();
                navigate('/research');
              }}
              className="hover:text-white transition-colors"
            >
              Research
            </a>
            <a
              href="/contact"
              onClick={(e) => {
                e.preventDefault();
                navigate('/contact');
              }}
              className="hover:text-white transition-colors"
            >
              Contact
            </a>
            <button
              type="button"
              onClick={() => setResumeOpen(true)}
              className="hover:text-white transition-colors cursor-pointer"
            >
              Resume
            </button>
          </div>
        </div>
      </footer>

      {/* Modals */}
      <ProjectDetailModal
        project={selectedProject}
        onClose={() => setSelectedProject(null)}
        onSelectProject={(project) => setSelectedProject(project)}
        allProjects={PROJECTS}
      />

      <ResumeModal isOpen={resumeOpen} onClose={() => setResumeOpen(false)} />
    </div>
  );
}
