export type ProjectFilterGroup = 'all' | 'deployed' | 'research' | 'systems' | 'design';

export interface ProjectItem {
  id: string;
  index: string;
  name: string;
  fullTitle: string;
  categoryLabel: string;
  filterGroup: Exclude<ProjectFilterGroup, 'all'>;
  status: string;
  statusTone: 'emerald' | 'blue' | 'amber' | 'slate';
  yearOrPhase: string;
  summary: string;
  image?: string;
  imageAlt?: string;
  stack: string[];
  team?: string;
  guide?: string;
  interfaces?: string[];
  researchAngle?: string;
  evaluationPlan?: string[];
  outputs?: string[];
  highlights: string[];
  honestyNote?: string;
  externalUrl?: string;
  externalLabel?: string;
  featured: boolean;
}

export interface SkillGroup {
  id: string;
  index: string;
  title: string;
  emphasis: string;
  description: string;
  skills: {
    name: string;
    context: string;
    primary?: boolean;
  }[];
}

export interface ResearchOutput {
  id: string;
  index: string;
  title: string;
  venueOrType: string;
  status: string;
  collaborators: string;
  description: string;
  formats: string[];
}

export interface ExperienceItem {
  id: string;
  role: string;
  organization: string;
  type: string;
  highlights: string[];
}

export const PORTFOLIO_PROFILE = {
  brand: 'BROOT_01',
  name: 'Sachin Raja S J',
  roleHeadline: 'Computer Science Student · Java Full Stack & AI Systems',
  heroSummary:
    'Final-year B.E. Computer Science and Engineering student at K.S. Rangasamy College of Technology, Tiruchengode (CGPA: 7.45). Trained in Java Full Stack Development via Eduskills, building structured backend services, SQL/NoSQL databases, and AI-assisted systems.',
  institution: 'K.S. Rangasamy College of Technology (Autonomous), Tiruchengode',
  degree: 'Bachelor of Engineering – Computer Science and Engineering',
  batch: '2023–2027',
  cgpa: '7.45',
  careerFocus: 'Java Full Stack Development',
  location: 'Tiruchengode, Tamil Nadu, India',
  phone: '+91 8825514048',
  resumePdfUrl: '/assets/aistudio/26_24__resume_916bac21.pdf',
  heroImage: '/src/assets/images/hero_architecture_visual_1795597039902.jpg',
  links: {
    email: 'sjsachinraja@gmail.com',
    github: 'https://github.com/sjsachinraja2006',
    linkedin: 'https://www.linkedin.com/in/sachinraja-s-j-93b0792b1/',
  },
};

export const KEY_HIGHLIGHTS = [
  {
    value: '7.45 CGPA',
    label: 'B.E. CSE (2023–2027) · KSRCT Autonomous',
  },
  {
    value: 'Java Full Stack',
    label: 'Eduskills Intern · Core Java, JDBC, JSP & MySQL',
  },
  {
    value: '50 Papers',
    label: 'Synthesized Across 2 Literature Reviews',
  },
  {
    value: '8 Projects',
    label: 'Live UI, Prototypes, Research & Concepts',
  },
];

export const PROJECTS: ProjectItem[] = [
  {
    id: 'pixelnest',
    index: '01',
    name: 'PixelNest',
    fullTitle: 'PixelNest — AI-Powered Web Development & Creative Collaboration Platform',
    categoryLabel: 'Web Platform · UI Engineering',
    filterGroup: 'deployed',
    status: 'UI Completed & Deployed',
    statusTone: 'emerald',
    yearOrPhase: 'Live UI & Ongoing Features',
    summary:
      'Web platform helping users create modern responsive websites with AI-assisted design, creative collaboration workflows, user authentication, and project management ("Connect · Collaborate · Create").',
    image: '/src/assets/images/project_pixelnest_preview_1795597040618.jpg',
    imageAlt: 'Minimalist dark editorial interface cards representing the PixelNest web platform',
    stack: ['HTML5', 'CSS3', 'JavaScript', 'UI/UX Design', 'AI-Assisted Workflow'],
    highlights: [
      'Complete frontend user interface built and deployed with responsive layouts and intuitive UX.',
      'Structured workflows for user authentication, project management, and creative collaborator discovery.',
      'AI-assisted design direction streamlined for clean, modern web development.',
    ],
    externalLabel: 'Portfolio Reference Ready',
    featured: true,
  },
  {
    id: 'evalpoint',
    index: '02',
    name: 'EvalPoint',
    fullTitle: 'A Language Model-Based Framework for Automated Assessment of Student Responses and Intelligent Scoring Assistance',
    categoryLabel: 'Final Year Project · EdTech & AI',
    filterGroup: 'research',
    status: 'Planning Stage · Research',
    statusTone: 'blue',
    yearOrPhase: 'Final Year Project',
    summary:
      'Rubric-grounded LLM scoring architecture with criterion-level explanations, an automated evidence verification layer, and mandatory teacher review and approval before any grade is published.',
    image: '/src/assets/images/project_evalpoint_system_1795597042492.jpg',
    imageAlt: 'Isometric layered verification architecture representing EvalPoint rubric-grounded assessment and human review',
    stack: ['Spring Boot', 'MySQL / PostgreSQL', 'LLM API', 'Java', 'Analytics'],
    team: 'Sachin Raja S J, Subhiksha S',
    guide: 'Rajkumar S (Guide & Co-author)',
    interfaces: [
      'Teacher Evaluation & Approval Portal',
      'Student Response Submission Portal',
      'Assignment & Rubric Management Console',
    ],
    researchAngle:
      'Combines rubric-grounded scoring, evidence verification, uncertainty-aware human review, optional camera-event monitoring (with alerts kept strictly separate from academic scores), and centralized performance analytics.',
    evaluationPlan: [
      'Scoring agreement & Mean Absolute Error (MAE) against human graders',
      'Rubric alignment & inter-run scoring consistency',
      'Criterion-level feedback quality & teacher review efficiency',
      'Camera-event precision/recall (isolated from grade calculation)',
      'System usability, privacy safeguards, and data security audit',
    ],
    outputs: [
      '25-paper structured literature review on LLM-assisted grading',
      'IEEE-format research manuscript (Overleaf LaTeX & Word drafts)',
    ],
    highlights: [
      'Human-in-the-loop gate ensures LLM outputs remain scoring assistance until teacher sign-off.',
      'Integrity alerts from optional camera monitoring are isolated from score computation to preserve fairness.',
      'Designed around a Java Spring Boot backend with relational rubric/submission persistence.',
    ],
    honestyNote:
      'Currently in the research and architecture planning stage. No accuracy metrics or empirical benchmarks are claimed prior to implementation and evaluation.',
    featured: true,
  },
  {
    id: 'smart-flood-intelligence',
    index: '03',
    name: 'Smart Flood Intelligence System',
    fullTitle: 'Smart Flood Intelligence System — Rainfall & Hydrological RAG Insights',
    categoryLabel: 'Disaster Management · Applied AI',
    filterGroup: 'systems',
    status: 'Technical Build',
    statusTone: 'amber',
    yearOrPhase: 'Applied AI System',
    summary:
      'An AI decision-support system that analyzes regional rainfall measurements alongside a curated flood management knowledge base using retrieval-augmented generation and GIS layers.',
    image: '/src/assets/images/project_flood_gis_1795597042130.jpg',
    imageAlt: 'Dark topographic hydrological elevation map with cobalt contour lines for flood intelligence',
    stack: ['Python', 'RAG', 'FAISS', 'GIS'],
    highlights: [
      'Vector indexing with FAISS over domain-specific flood response protocols and hydrological guidelines.',
      'Contextualizes precipitation inputs with geospatial terrain context to surface actionable risk summaries.',
      'Modular Python pipeline separating retrieval indexing from risk synthesis queries.',
    ],
    featured: true,
  },
  {
    id: 'farmer-price-platform',
    index: '04',
    name: 'Farmer-to-Buyer Price Transparency Platform',
    fullTitle: 'Farmer-to-Buyer Price Transparency & Mandi Analytics Platform',
    categoryLabel: 'AgriTech · Full-Stack & SQL Analytics',
    filterGroup: 'systems',
    status: 'Technical Build',
    statusTone: 'amber',
    yearOrPhase: 'Full-Stack & Data Engineering',
    summary:
      'Marketplace and price intelligence platform where farmers list produce while daily mandi prices are collected via automated Linux cron jobs, uncovering moving averages and regional price spreads.',
    image: '/src/assets/images/project_agri_platform_1795597042497.jpg',
    imageAlt: 'Dark architectural grid terraces with crisp market trend line contours representing agricultural price transparency',
    stack: ['React', 'FastAPI / Node.js', 'PostgreSQL', 'SQL Window Functions', 'Linux Cron'],
    highlights: [
      'Automated daily mandi price ingestion scheduled via Linux cron jobs into normalized price history tables.',
      'PostgreSQL analytical queries using SQL window functions to compute rolling moving averages and region-wise price comparisons.',
      'High-contrast, cinematic interface designed to help growers evaluate the best time and market to sell.',
    ],
    featured: true,
  },
  {
    id: 'curriculum-analysis',
    index: '05',
    name: 'Curriculum Analysis & Time Estimation',
    fullTitle: 'An Intelligent Approach to Curriculum Analysis and Instructional Time Estimation',
    categoryLabel: 'Academic Prototype · Phase-I Report',
    filterGroup: 'research',
    status: 'Phase-I Prototype Complete',
    statusTone: 'blue',
    yearOrPhase: 'November 2026',
    summary:
      'Project Phase-I report and functional prototype covering syllabus upload, automated analysis preview, instructional pacing dashboard, and validation test interface.',
    stack: ['Python', 'Syllabus Parsing', 'Dashboard UI', 'Literature Synthesis'],
    outputs: [
      'Project Phase-I Report (November 2026)',
      '25-paper literature review on curriculum modeling & instructional time estimation',
    ],
    highlights: [
      'End-to-end prototype workflow spanning Upload Page, Analysis Preview, Instructional Dashboard, and Test Interface.',
      'Grounded in a 25-paper literature review examining topic density and credit-hour estimation methods.',
    ],
    featured: false,
  },
  {
    id: 'ipl-analysis',
    index: '06',
    name: 'IPL Analysis Dashboard',
    fullTitle: 'IPL Cricket Performance & Match Trend Analytics',
    categoryLabel: 'Data Visualization · Business Intelligence',
    filterGroup: 'systems',
    status: 'Data Visualization',
    statusTone: 'slate',
    yearOrPhase: 'Power BI Analytics',
    summary:
      'Interactive Power BI analytics project examining historical IPL datasets across franchise win rates, player season consistency, and venue/match-phase trends.',
    stack: ['Power BI', 'Data Modeling', 'DAX', 'Statistical Charts'],
    highlights: [
      'Structured relational dataset modeling for multi-season match, team, and player comparisons.',
      'Visual breakdown of team consistency, strike-rate distributions, and toss-vs-outcome patterns.',
    ],
    featured: false,
  },
  {
    id: 'barber-shop-ui',
    index: '07',
    name: 'Barber Shop UI',
    fullTitle: 'Barber Shop Grooming Studio — Booking Flow & Service Interface',
    categoryLabel: 'UI/UX Design · Figma',
    filterGroup: 'design',
    status: 'UI/UX Design',
    statusTone: 'slate',
    yearOrPhase: 'Figma Prototype',
    summary:
      'End-to-end mobile and web UI/UX exploration for a modern grooming studio featuring service tiers, stylist selection, and friction-free appointment slot booking.',
    stack: ['Figma', 'Design Systems', 'Booking Flow UX', 'Typography'],
    highlights: [
      'Designed clear visual hierarchy for grooming packages, pricing clarity, and step-by-step slot confirmation.',
      'Focused on mobile thumb reachability and clean visual rhythm between imagery and booking controls.',
    ],
    featured: false,
  },
  {
    id: 'kiddo-mart',
    index: '08',
    name: 'Kiddo Mart',
    fullTitle: 'Kiddo Mart — Kids Commerce Storefront Concept',
    categoryLabel: 'Product Concept · UI Exploration',
    filterGroup: 'design',
    status: 'Concept Design',
    statusTone: 'slate',
    yearOrPhase: 'Concept Exploration',
    summary:
      'Conceptual e-commerce storefront architecture designed around age-group filtering, parent-friendly safety metadata, and playful yet structured product browsing.',
    stack: ['UI/UX Concept', 'Information Architecture', 'HTML / CSS'],
    highlights: [
      'Structured category navigation tailored for age brackets, educational toys, and seasonal essentials.',
      'Presented transparently as a design concept prior to full backend implementation.',
    ],
    featured: false,
  },
];

export const SKILL_GROUPS: SkillGroup[] = [
  {
    id: 'java-backend',
    index: '01',
    title: 'Java Full Stack & Core Concepts',
    emphasis: 'Primary Career Track',
    description:
      'Object-oriented programming, DBMS, REST APIs, and server-side Java fundamentals backed by hands-on Eduskills internship training.',
    skills: [
      { name: 'Java & OOP', context: 'Core Java, collections & object-oriented design', primary: true },
      { name: 'JDBC & JSP', context: 'Server pages & relational Java connectivity', primary: true },
      { name: 'Spring Boot & REST APIs', context: 'Service endpoints & EvalPoint backend architecture', primary: true },
      { name: 'Python & FastAPI', context: 'RAG pipelines, scraping services & REST backends' },
    ],
  },
  {
    id: 'databases',
    index: '02',
    title: 'Databases & SQL Engineering',
    emphasis: 'Relational & NoSQL',
    description:
      'Schema modeling, DBMS fundamentals, NoSQL document storage, and analytical SQL querying with window functions.',
    skills: [
      { name: 'MySQL', context: 'Relational schemas, XAMPP & JDBC persistence', primary: true },
      { name: 'PostgreSQL & Window Functions', context: 'Price history tables & moving averages', primary: true },
      { name: 'MongoDB', context: 'Document-oriented NoSQL data modeling', primary: true },
      { name: 'DBMS Fundamentals', context: 'Normalization, indexing & transactional queries' },
    ],
  },
  {
    id: 'frontend',
    index: '03',
    title: 'Frontend, UI/UX & Dev Tools',
    emphasis: 'Web & Creative Tooling',
    description:
      'Responsive interfaces from web fundamentals and Bootstrap up to React dashboards, Figma prototypes, and creative/IDE tooling.',
    skills: [
      { name: 'HTML5, CSS3 & Bootstrap', context: 'Semantic markup & responsive grid layouts', primary: true },
      { name: 'JavaScript & React', context: 'Interactive web flows & analytics dashboards', primary: true },
      { name: 'VS Code, Eclipse & XAMPP', context: 'Java/web IDE workflows & local server stack' },
      { name: 'Figma, Canva & 3D Tools', context: 'UI design, Unity Hub, Blender & Autodesk' },
    ],
  },
  {
    id: 'ai-systems',
    index: '04',
    title: 'AI/ML, Automation & Writing',
    emphasis: 'Applied Systems & Research',
    description:
      'Practical integration of language models, vector retrieval, geospatial analysis, Linux cron jobs, and formal academic writing.',
    skills: [
      { name: 'LLM Integration & RAG', context: 'Rubric-grounded scoring & retrieval workflows' },
      { name: 'FAISS & GIS', context: 'Vector search & flood risk spatial insights' },
      { name: 'Linux Cron Automation', context: 'Scheduled daily mandi price scraping' },
      { name: 'Power BI & IEEE Writing', context: 'Cricket analytics, Overleaf papers & lit reviews' },
    ],
  },
];

export const EXPERIENCE_ITEMS: ExperienceItem[] = [
  {
    id: 'eduskills-java',
    role: 'Java Full Stack Development Internship',
    organization: 'Eduskills',
    type: 'Internship & Hands-On Training',
    highlights: [
      'Completed structured training in Core Java, OOP, HTML, CSS, JavaScript, Bootstrap, JDBC, JSP, REST APIs, and MySQL.',
      'Developed responsive web pages and completed hands-on full-stack projects.',
    ],
  },
];

export const CERTIFICATIONS: string[] = [
  'Java Full Stack Development Internship – Eduskills',
  'NASSCOM Digital Engineering Certification',
  'Wadhwani Foundation – Ignite India Program',
  'Technical Events & Project Exhibitions Participant',
];

export const SOFT_SKILLS: string[] = [
  'Problem Solving',
  'Teamwork',
  'Communication',
  'Adaptability',
  'Time Management',
  'Quick Learner',
];

export const RESEARCH_OUTPUTS: ResearchOutput[] = [
  {
    id: 'ieee-evalpoint',
    index: '01',
    title: 'A Language Model-Based Framework for Automated Assessment of Student Responses and Intelligent Scoring Assistance',
    venueOrType: 'IEEE-Format Manuscript · Final Year Research',
    status: 'Drafted (Overleaf & Word) · System in Planning Stage',
    collaborators: 'Sachin Raja S J, Subhiksha S · Guide & Co-author: Rajkumar S',
    description:
      'Proposes a rubric-grounded LLM assessment architecture featuring an evidence verification layer, uncertainty-aware teacher approval gates, optional isolated camera-event flagging, and centralized analytics.',
    formats: ['IEEE LaTeX (Overleaf)', 'Microsoft Word Draft'],
  },
  {
    id: 'lit-review-evalpoint',
    index: '02',
    title: 'Literature Review: LLM-Based Automated Student Assessment & Rubric Grounding',
    venueOrType: '25-Paper Literature Synthesis',
    status: 'Completed',
    collaborators: 'EvalPoint Research Track',
    description:
      'Systematic analysis of 25 peer-reviewed studies examining automated essay scoring, rubric alignment, hallucination mitigation, scoring consistency (MAE/QWK), and human-in-the-loop grading workflows.',
    formats: ['Structured Matrix', '25 Peer-Reviewed Papers'],
  },
  {
    id: 'curriculum-phase1',
    index: '03',
    title: 'An Intelligent Approach to Curriculum Analysis and Instructional Time Estimation',
    venueOrType: 'Project Phase-I Report & 25-Paper Literature Review',
    status: 'Phase-I Submitted · November 2026',
    collaborators: 'K.S. Rangasamy College of Technology · B.E. CSE',
    description:
      'Comprehensive Phase-I engineering report combining a 25-paper literature review with a working prototype covering syllabus upload, automated analysis preview, instructional dashboard, and test interface.',
    formats: ['Phase-I Report (Nov 2026)', '25-Paper Review', 'Prototype UI'],
  },
];
