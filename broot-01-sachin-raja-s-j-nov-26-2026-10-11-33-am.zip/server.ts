import 'dotenv/config';
import express from 'express';
import fs from 'fs';
import path from 'path';
import nodemailer from 'nodemailer';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT || 3000);
const DEFAULT_RECEIVER_EMAIL = 'sjsachinraja@gmail.com';

// Simple in-memory per-IP sliding window rate limiter for /api/contact
const RATE_WINDOW_MS = 15 * 60 * 1000;
const RATE_MAX_REQUESTS = 5;
const rateBuckets = new Map<string, number[]>();

function isRateLimited(ip: string): boolean {
  const now = Date.now();
  const timestamps = (rateBuckets.get(ip) || []).filter((ts) => now - ts < RATE_WINDOW_MS);
  if (timestamps.length >= RATE_MAX_REQUESTS) {
    rateBuckets.set(ip, timestamps);
    return true;
  }
  timestamps.push(now);
  rateBuckets.set(ip, timestamps);
  return false;
}

function stripHeaderControls(value: string): string {
  return value.replace(/[\r\n\t]+/g, ' ').trim();
}

function escapeHtml(value: string): string {
  return value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function hasSmtpConfig(): boolean {
  return Boolean(process.env.SMTP_USER?.trim() && process.env.SMTP_PASS?.trim());
}

function hasResendConfig(): boolean {
  return Boolean(process.env.RESEND_API_KEY?.trim());
}

async function startServer() {
  const app = express();
  app.disable('x-powered-by');
  app.set('trust proxy', 1);

  app.use((_req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    next();
  });

  app.use(express.json({ limit: '16kb' }));

  app.get('/api/contact/status', (_req, res) => {
    res.json({
      emailConfigured: hasSmtpConfig() || hasResendConfig(),
    });
  });

  app.post('/api/contact', async (req, res) => {
    const clientIp = req.ip || req.socket.remoteAddress || 'unknown';
    if (isRateLimited(clientIp)) {
      res.status(429).json({
        ok: false,
        error: 'Too many messages sent recently. Please wait a few minutes before trying again.',
      });
      return;
    }

    const rawBody = req.body;
    if (!rawBody || typeof rawBody !== 'object') {
      res.status(400).json({ ok: false, error: 'Invalid request payload.' });
      return;
    }

    const { name, email, subject, message } = rawBody as Record<string, unknown>;

    if (
      typeof name !== 'string' ||
      typeof email !== 'string' ||
      typeof subject !== 'string' ||
      typeof message !== 'string'
    ) {
      res.status(400).json({ ok: false, error: 'All contact fields must be text strings.' });
      return;
    }

    const cleanName = stripHeaderControls(name);
    const cleanEmail = stripHeaderControls(email);
    const cleanSubject = stripHeaderControls(subject);
    const cleanMessage = message.trim();

    if (cleanName.length < 2 || cleanName.length > 100) {
      res.status(400).json({ ok: false, error: 'Please enter a name between 2 and 100 characters.' });
      return;
    }

    if (cleanEmail.length > 160 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
      res.status(400).json({ ok: false, error: 'Please enter a valid email address.' });
      return;
    }

    if (cleanSubject.length < 2 || cleanSubject.length > 150) {
      res.status(400).json({ ok: false, error: 'Please enter a subject between 2 and 150 characters.' });
      return;
    }

    if (cleanMessage.length < 10 || cleanMessage.length > 3000) {
      res.status(400).json({
        ok: false,
        error: 'Please enter a message between 10 and 3000 characters.',
      });
      return;
    }

    const receiverEmail = stripHeaderControls(
      process.env.CONTACT_RECEIVER_EMAIL?.trim() ||
        process.env.SMTP_USER?.trim() ||
        DEFAULT_RECEIVER_EMAIL
    );

    const plainText = [
      'New message from BROOT_01 Portfolio Contact Form',
      '--------------------------------------------------',
      `From: ${cleanName} <${cleanEmail}>`,
      `Subject: ${cleanSubject}`,
      '',
      cleanMessage,
    ].join('\n');

    const htmlBody = `
      <div style="font-family: sans-serif; color: #0f172a; line-height: 1.6;">
        <h2 style="margin-bottom: 12px;">New Portfolio Inquiry — BROOT_01</h2>
        <p><strong>From:</strong> ${escapeHtml(cleanName)} (${escapeHtml(cleanEmail)})</p>
        <p><strong>Subject:</strong> ${escapeHtml(cleanSubject)}</p>
        <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 16px 0;" />
        <p style="white-space: pre-wrap;">${escapeHtml(cleanMessage)}</p>
      </div>
    `;

    // 1. Attempt SMTP delivery via Nodemailer if configured
    if (hasSmtpConfig()) {
      try {
        const host = process.env.SMTP_HOST?.trim() || 'smtp.gmail.com';
        const port = Number(process.env.SMTP_PORT || 465);
        const user = process.env.SMTP_USER!.trim();
        const pass = process.env.SMTP_PASS!.trim();

        const transporter = nodemailer.createTransport({
          host,
          port,
          secure: port === 465,
          auth: { user, pass },
        });

        await transporter.sendMail({
          from: `"BROOT_01 Portfolio" <${user}>`,
          to: receiverEmail,
          replyTo: `${cleanName} <${cleanEmail}>`,
          subject: `[Portfolio] ${cleanSubject}`,
          text: plainText,
          html: htmlBody,
        });

        res.json({
          ok: true,
          mode: 'smtp',
          message: 'Your message has been delivered directly to Sachin’s inbox.',
        });
        return;
      } catch (err) {
        console.error('SMTP email delivery failed:', err instanceof Error ? err.message : 'Unknown error');
        res.status(502).json({
          ok: false,
          error:
            'Could not send through the configured email server right now. Please try the direct email button below.',
        });
        return;
      }
    }

    // 2. Attempt Resend REST API if configured
    if (hasResendConfig()) {
      try {
        const resendKey = process.env.RESEND_API_KEY!.trim();
        const response = await fetch('https://api.resend.com/emails', {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${resendKey}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            from: 'BROOT_01 Portfolio <onboarding@resend.dev>',
            to: [receiverEmail],
            reply_to: cleanEmail,
            subject: `[Portfolio] ${cleanSubject}`,
            text: plainText,
            html: htmlBody,
          }),
        });

        if (!response.ok) {
          throw new Error(`Resend returned status ${response.status}`);
        }

        res.json({
          ok: true,
          mode: 'resend',
          message: 'Your message has been delivered directly to Sachin’s inbox.',
        });
        return;
      } catch (err) {
        console.error('Resend delivery failed:', err instanceof Error ? err.message : 'Unknown error');
        res.status(502).json({
          ok: false,
          error:
            'Could not send through the email relay right now. Please try the direct email button below.',
        });
        return;
      }
    }

    // 3. Honest fallback when server email secrets are not configured yet
    res.json({
      ok: true,
      mode: 'mailto_fallback',
      receiverEmail,
      message:
        'Your message was validated, but server email credentials (SMTP_USER / SMTP_PASS) are not configured yet. Opening your email app as a fallback.',
    });
  });

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      const indexFile = path.join(distDir, 'index.html');
      if (fs.existsSync(indexFile)) {
        res.sendFile(indexFile);
      } else {
        res.status(404).send('Application build not found.');
      }
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
